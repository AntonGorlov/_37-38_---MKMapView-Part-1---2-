//
//  UIView+MKAnnotationView.m
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 13.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "UIView+MKAnnotationView.h"
#import <MapKit/MKAnnotationView.h>

@implementation UIView (MKAnnotationView)


- (MKAnnotationView*) superAnnotationView {

    if ([self isKindOfClass:[MKAnnotationView class]]) {
        return (MKAnnotationView *) self;
    }
    
    if (!self.superview) {
        
        return nil;
    }

    return [self.superview superAnnotationView];

}

@end
