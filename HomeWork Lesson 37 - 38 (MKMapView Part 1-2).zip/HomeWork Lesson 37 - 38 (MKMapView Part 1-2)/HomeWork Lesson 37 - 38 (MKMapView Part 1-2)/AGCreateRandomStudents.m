//
//  AGCreateRandomStudents.m
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCreateRandomStudents.h"

@interface AGCreateRandomStudents ()

@property (strong, nonatomic) NSArray* namesArray;
@property (strong, nonatomic) NSArray* surnamesArray;
@property (strong, nonatomic) NSArray* femaleNames;
@property (assign, nonatomic) CLLocation* centerLocation;
@property (strong, nonatomic) CLGeocoder* geoCoder;

@end

@implementation AGCreateRandomStudents


- (id) initWithStudentLocation:(CLLocationCoordinate2D) centerPoint {

   // centerPoint - наша геолокация, относительно которой генерируются координаты студентов.
    
    // Создаем студента со всей информацией о нем!
    
    self = [super init];
    
    if (self) {
        
         self.distanceToMeeting = 0;
        
        self.namesArray = [NSArray array];
        self.surnamesArray = [NSArray array];
        self.femaleNames = [NSArray array];
        self.geoCoder = [[CLGeocoder alloc] init];
        
        
        //All names
        self.namesArray = [NSArray arrayWithObjects:
                           
                           @"Jula",    @"Elena", @"Katja",    @"Karina",
                           @"Marina",  @"Anna",  @"Sveta",    @"Jena",
                           @"Olga",    @"Alina", @"Nina",     @"Ira",
                           @"Kristina",@"Tanja", @"Alena",    @"Adriano",
                           @"Leo",     @"Anton", @"Donatello",@"Evgen",
                           @"Petja",   @"Simon", @"Kolja",    @"Ivan",
                           @"Robin",   @"Denis", @"Bogdan",   @"Roma",
                           @"Bastian", @"Andrey" , nil];
     
        
        
        
        //woman names
        
        self.femaleNames = [NSArray arrayWithObjects:
                            
                            @"Jula",    @"Elena", @"Katja",@"Karina",
                            @"Marina",  @"Anna",  @"Sveta",@"Jena",
                            @"Olga",    @"Alina", @"Nina", @"Ira",
                            @"Kristina",@"Tanja", @"Alena", nil];
        
        
        
        
        
        self.firstName = [NSString stringWithFormat:@"%@",[self.namesArray objectAtIndex:arc4random_uniform((int) [self.namesArray count])]];
        
         // Выбор пола в зависимости от имени
        
        if ([self.femaleNames containsObject:self.firstName]) {
            
            self.gender = @"Female";
            
        }else {
        
        self.gender = @"Male";
            
        }
        
        self.surnamesArray = [NSArray arrayWithObjects:
                              
              @"Travolta",       @"Zidan",      @"Kruger",    @"Pele",
              @"Tarantino",      @"Klichko",    @"Bangura",   @"Olisadebe",
              @"Lumumba",        @"Primus",     @"Messi",     @"Javier",
              @"Schweinsteiger", @"Krjatov",    @"Oblomov",   @"Kurve",
              @"Calentano",      @"Poroshenko", @"Janukovich",@"Uchenko",
              @"Putin",          @"Stallone",   @"Rambo",     @"Balboa",
              @"Good",           @"Repa",       @"Gamula",    @"Luchesku",
              @"Markevich",      @"Rikun" ,  nil];
        
        
        self.lastName = [NSString stringWithFormat:@"%@", [self.surnamesArray objectAtIndex:arc4random_uniform((int) [self.surnamesArray count])]];
        
        //  День рождения делаем через NSDate, рандомно от какой-то даты. например 01.01.1993 + 5 лет диапазон для студента
        
        
        NSDateFormatter *dateFormatter =[[NSDateFormatter alloc]init];
        
        [dateFormatter setDateFormat:@"dd.MM.yyyy"];
        
        NSDate* startingDate = [dateFormatter dateFromString:@"01.01.1993"];
        
        // 5 лет в секундах = 60*60*24*365*5
        //Метод dateByAddingTimeInterval в качестве входного параметра принимает целочисленное значение количества секунд на сколько вы хотите увеличить значение даты, а возвращает новый объект с результатом добавления.
        self.dateOfBirth = [startingDate dateByAddingTimeInterval:arc4random_uniform(60*60*24*365*5)];
        
        // генерируем геопозицию для студента
        
        if (centerPoint.latitude && centerPoint.longitude) {
            
            CGFloat deltaX,deltaY;
            
            // диапазон дельт по широте и долготе (+ - 0.05)
            
            deltaX = ((double)arc4random_uniform(20001)-10000)/200000;
            deltaY = ((double)arc4random_uniform(20001)-10000)/200000;
            
               NSLog(@"deltas - %f, %f", deltaY, deltaX);
            
            self.coordinate = CLLocationCoordinate2DMake(centerPoint.latitude + deltaY, centerPoint.longitude + deltaX);
            
            // NSLog(@"Coordinates: latitude - %f, longitude - %f", self.coordinate.latitude, self.coordinate.longitude);
        }
        

        
        self.title = [NSString stringWithFormat:@"%@ %@", self.firstName,self.lastName];
        
        self.subtitle = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:self.dateOfBirth]];
        
    }


    return self;
}

@end
