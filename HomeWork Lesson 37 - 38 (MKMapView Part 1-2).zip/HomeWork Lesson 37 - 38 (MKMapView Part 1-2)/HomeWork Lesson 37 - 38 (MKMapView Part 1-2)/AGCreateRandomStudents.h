//
//  AGCreateRandomStudents.h
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "ViewController.h"

@interface AGCreateRandomStudents : NSObject <MKAnnotation> // Реализовали тут протокол, чтобы объекты данного класса отображать на карте

@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString* gender;
@property (assign, nonatomic) NSDate* dateOfBirth;
@property (strong, nonatomic) NSString* address;
@property (assign, nonatomic) double distanceToMeeting;

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;


- (id) initWithStudentLocation:(CLLocationCoordinate2D) centerPoint;
@end
