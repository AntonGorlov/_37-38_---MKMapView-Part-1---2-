//
//  AGDescriptionPopover.h
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 14.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGDescriptionPopover : UITableViewController


@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *lastNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateOfBirhtLabel;
@property (weak, nonatomic) IBOutlet UILabel *genderLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;

@property (strong, nonatomic) NSString* userName;
@property (strong, nonatomic) NSString* userLastName;
@property (strong, nonatomic) NSString* userDateOfBirth;
@property (strong, nonatomic) NSString* userGender;
@property (strong, nonatomic) NSString* userAddress;
@end
