//
//  AGMeetingCell.h
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 13.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGMeetingInfoTableViewController.h"

@interface AGMeetingCell : UITableViewCell

// Класс для нашей кастомной ячейки
@property (weak, nonatomic) IBOutlet UILabel *nameSurnameLabel;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UIImageView *yesOrNoView;

@end
