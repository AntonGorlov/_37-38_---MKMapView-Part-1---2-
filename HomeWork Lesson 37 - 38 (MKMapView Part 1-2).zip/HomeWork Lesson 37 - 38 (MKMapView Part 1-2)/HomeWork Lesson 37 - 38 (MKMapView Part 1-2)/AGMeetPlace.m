//
//  AGMeetPlace.m
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 13.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGMeetPlace.h"

@implementation AGMeetPlace

// создали отдельный класс, с которым будем инициализировать метку встречи по отправленной координате meetPlaceCoordinate

- (instancetype) initWithMeetPlace:(CLLocationCoordinate2D) meetPlaceCoordinate {

    self = [super init];
    
    if (self) {
        
        self.coordinate = meetPlaceCoordinate;
        
        self.title = @"MEETING PLACE";
        
        self.subtitle = [NSString stringWithFormat:@"latitude - %.2f longitude - %.2f", self.coordinate.latitude, self.coordinate.longitude];
    }
    
    return self;
}

@end
