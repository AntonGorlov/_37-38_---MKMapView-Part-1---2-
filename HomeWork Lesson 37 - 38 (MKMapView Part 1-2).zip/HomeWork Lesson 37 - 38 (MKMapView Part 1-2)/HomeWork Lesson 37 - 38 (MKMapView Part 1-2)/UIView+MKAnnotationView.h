//
//  UIView+MKAnnotationView.h
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 13.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MKAnnotationView;

@interface UIView (MKAnnotationView)

// Категория, где мы делаем рекурсию, для того чтобы определять, по какой именно кнопке информации какого студента мы нажимаем.

- (MKAnnotationView*) superAnnotationView;
@end
