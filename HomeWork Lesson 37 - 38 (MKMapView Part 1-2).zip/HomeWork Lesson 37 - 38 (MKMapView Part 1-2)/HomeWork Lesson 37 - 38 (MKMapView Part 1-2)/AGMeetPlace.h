//
//  AGMeetPlace.h
//  HomeWork Lesson 37 - 38 (MKMapView Part 1-2)
//
//  Created by Anton Gorlov on 13.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "ViewController.h"

@interface AGMeetPlace : NSObject <MKAnnotation>

// Класс для места встречи

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;


@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;

- (instancetype) initWithMeetPlace:(CLLocationCoordinate2D) meetPlaceCoordinate;


@end
