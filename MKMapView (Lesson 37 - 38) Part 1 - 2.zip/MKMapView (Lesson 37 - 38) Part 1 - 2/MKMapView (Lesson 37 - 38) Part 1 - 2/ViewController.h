//
//  ViewController.h
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@class MKMapView; //добавляем как класс (этот framework можно через #import, но мы не любим так делать,лучше перенести во внутрирь нашей имплементации)

@interface ViewController : UIViewController

@property (strong, nonatomic) CLLocationManager *locationManager; //чтобы получить текущее местоположение
@property (strong, nonatomic) CLLocation *location; //чтобы получить текущее местоположение
@property (weak, nonatomic)  UISegmentedControl *segmentedControl;
@property (weak, nonatomic) IBOutlet UISearchBar *searchForPlaces;

@property (strong, nonatomic) IBOutlet MKMapView *mapView; //добавим как свойство (но его здесь нет,так как наш конроллер не знает,что такое *mapView, добавим выше"@class MKMapView;")
@end

