//
//  AppDelegate.h
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

