//
//  AGMapAnnotation.h
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <MapKit/MKAnnotation.h> //добавим frameWork
@interface AGMapAnnotation : NSObject <MKAnnotation>//протокол

@property (nonatomic, assign) CLLocationCoordinate2D coordinate; //обязательным являеться координаты
@property (nonatomic,  copy,  nullable) NSString *title;
@property (nonatomic,  copy,  nullable) NSString *subtitle;

//redonly удалим (redonly говорит,что в этом классе должен быть геттер,если убрать redonly ,то будет и геттер и сеттер )
@end
