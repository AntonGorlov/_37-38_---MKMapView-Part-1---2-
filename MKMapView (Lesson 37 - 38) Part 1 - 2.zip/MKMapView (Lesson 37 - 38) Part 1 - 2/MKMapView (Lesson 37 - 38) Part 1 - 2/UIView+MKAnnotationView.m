//
//  UIView+MKAnnotationView.m
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//


#import "UIView+MKAnnotationView.h"
#import <MapKit/MKAnnotationView.h> //добавляем framework
@implementation UIView (MKAnnotationView)


-(MKAnnotationView*) superAnnotationView {
    
    if ([self isKindOfClass:[MKAnnotationView class]]) { //если наш self является MKAnnotationView
        
        return (MKAnnotationView*)self;
    }
    
    if (!self.superview) { //если superview нет (ее может не быть,если view не добавилось еще на контроллер либо это UIWindow,смысла искать нет,если superview nil)
        return nil;
    }
    
    return [self.superview superAnnotationView]; //сделали рекурсивный метод (спрашиваем у superview не ты ли AnnotationView)
}

@end

//Это рекурсивный метод, который будет проходить по всем родителям (не важно,кнопка лежит сразу на AnnotationView или на 10-й глубине,она будет идти на верх и искать того,кто является AnnotationView )