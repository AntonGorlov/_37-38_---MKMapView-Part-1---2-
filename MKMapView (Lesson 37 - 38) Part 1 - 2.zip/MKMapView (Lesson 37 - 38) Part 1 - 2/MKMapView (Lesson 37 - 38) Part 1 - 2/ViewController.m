//
//  ViewController.m
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h> //добавляем вайл с framework  в "< >"
#import "AGMapAnnotation.h"
#import "UIView+MKAnnotationView.h" //добавляем нашу категорию (расширение)


@interface ViewController () <MKMapViewDelegate ,CLLocationManagerDelegate ,UISearchBarDelegate > //устанавливаем делегат,чтобы можно было реализовать его методы

@property (strong , nonatomic) CLGeocoder *geoCoder; //соз property,чтобы сохранять ссылку (для получения адреса по координатам)
@property (strong , nonatomic) MKDirections *directions; //соз property,чтобы сохранять направления.Не уверены,будет он без property делать retain (сохранить) или нет

typedef enum { //for segmentedControl
    
    AGMapTypeSegmentedControlStandard,
    AGMapTypeSegmentedControlSatellite,
    AGMapTypeSegmentedControlHybrid
    
    
}AGMapTypeSegmentedControl;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //чтобы получить текущиее местоположение
    
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    [self.locationManager requestAlwaysAuthorization];
    [self.locationManager stopUpdatingLocation];
    _mapView.showsUserLocation = YES;
    
    
    
    //Сделаем что-то интересное,добавим координату на "MapRect"
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                              target:self action:@selector(actionAdd:)];
    
    
    
    
    UIBarButtonItem *zoomButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSearch
                                                                               target:self action:@selector(actionShowAll:)];
    
    
    UIBarButtonItem *locationButton = [[UIBarButtonItem alloc] initWithTitle:@"My location"
                                                                       style:UIBarButtonItemStylePlain
                                                                      target:self
                                                                      action:@selector(actionMyLocation:)];
    
    
    UIBarButtonItem *removeAllPinButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemTrash
                                                                                       target:self action:@selector(actionRemoveAllPin:)];
    
    //ОТступы между UIBarButtonItem смотри распечатку по уроку 37 (стр 2)
    
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                                                               target:nil
                                                                               action:nil];
    
    fixedSpace.width = 23;
    
    self.navigationItem.rightBarButtonItems = [NSArray arrayWithObjects:  addButton,removeAllPinButton,zoomButton,locationButton,fixedSpace ,nil];
    //или @[zoomButton,addButton]
    
    UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Standard",@"Satellite",@"Hybrid", nil]];
    
    
    [segmentedControl addTarget:self action:@selector(actionChangeTypeMap:) forControlEvents:UIControlEventValueChanged];
    
    segmentedControl.frame = CGRectMake(0, 0, 400.0f, 30.0f);
    
    self.navigationItem.titleView = segmentedControl;
    
    segmentedControl.selectedSegmentIndex = AGMapTypeSegmentedControlStandard;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                 action:@selector(createPinTap:)];
    
    [self.mapView addGestureRecognizer:tapGesture];
    
    self.geoCoder = [[CLGeocoder alloc]init]; //инициализируем (создаем) Geocoder
}

#pragma mark- LocationManager

- (void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    //чтобы получить текущиее местоположение
    
    [self.locationManager requestAlwaysAuthorization];
    [self.locationManager stopUpdatingLocation];
    //self.locationManager = locations.lastObject;
    self.location = locations.lastObject;
    
    
}

#pragma mark- Gestures

- (void) createPinTap:(UITapGestureRecognizer*) tapGesture {
    
    [self createAnnotationForTap:tapGesture];
    
}


#pragma mark- Methods

- (AGMapAnnotation*) createAnnotationForTap:(UITapGestureRecognizer*) tapGesture {
    
    AGMapAnnotation *annotation = [[AGMapAnnotation alloc]init];
    annotation.title = @"Test title";
    annotation.subtitle = @"Test subtitle";
    
    if (tapGesture) {
        
        CLLocationCoordinate2D location = [self.mapView convertPoint:[tapGesture locationInView:self.mapView] //метод преобразует экранные координаты в map координаты (координаты view преобразует в координаты mapView )
                                                toCoordinateFromView:self.mapView];
        
        NSLog(@"You tapped at: %.3f, %.3f", location.latitude, location.longitude);
        annotation.coordinate = location;
        [self.mapView addAnnotation:annotation];
        
    } else {
        
        nil;
    }
    return annotation;
    
}
#pragma mark- Action

- (void) actionAdd:(UIBarButtonItem*) sender { //соз "Pin" красный шарик на палочке
    
    //будет показано то место,которое скажем.Жмем кнопку и "Pin" будет падать в центр экрана
    
    AGMapAnnotation *annotation = [[AGMapAnnotation alloc]init];
    annotation.title = @"Test title";
    annotation.subtitle = @"Test subtitle";
    annotation.coordinate = self.mapView.region.center; //у Map есть region (риджин),Который выводим на экран,тоесть центр карты будет соответствовать центру региона
    
    [self.mapView addAnnotation:annotation];
    
}

- (void) actionRemoveAllPin:(UIBarButtonItem*) sender { //удаляем все пины с карты
    
    [self.mapView removeAnnotations:self.mapView.annotations];
    
}
- (void) actionShowAll:(UIBarButtonItem*) sender { //покажем все "Pin" в зуме,чтобы все установленные на карте "Pinы" были видны.
    
    MKMapRect zoomRect = MKMapRectNull; //делаем нулевой Rect,как в CGRectZero
    
    for (id <MKAnnotation> annotation in self.mapView.annotations) { //проходим по всем анотациям (для каждого обьекта,кот реализует протокол <MKAnnotation>  в массиве annotations)
        
        CLLocationCoordinate2D location = annotation.coordinate; //берем location нашей анотации (Она в градусах,сферические координаты)
        
        MKMapPoint center = MKMapPointForCoordinate(location); //функция переводит в двумерные координаты (2D) создает 2-х мерную точку
        
        static double delta = 20000; //масштаб (чем меньше ,тем ближе к точке)
        
        MKMapRect rect = MKMapRectMake(center.x - delta, center.y - delta , delta * 2, delta * 2); //у нашей анотации отнимаем дельту
        
        
        zoomRect = MKMapRectUnion(zoomRect, rect); //обьединяем прямоугольники (сумма всех прам-ков)
    }
    
    zoomRect = [self.mapView mapRectThatFits:zoomRect]; // функция,которая сделает другой прямоугольник,кот будет помещаться в экране (подправит наш)
    
    
    [self.mapView setVisibleMapRect:zoomRect //отображаем на экране
                        edgePadding:UIEdgeInsetsMake(100, 100, 100, 100) //отступы от прямо-ка относительно mapView
                           animated:YES];
    
}

- (void) actionMyLocation:(UIBarButtonItem*) sender {
    
    [self.mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES]; // при загрузке карты,метод показывает координаты пользователя
    
}

- (void) actionChangeTypeMap:(UISegmentedControl*) sender {
    
    switch (sender.selectedSegmentIndex) {
        case AGMapTypeSegmentedControlStandard:
            
            self.mapView.mapType = MKMapTypeStandard;
            break;
            
        case AGMapTypeSegmentedControlSatellite:
            
            self.mapView.mapType = MKMapTypeSatellite;
            break;
            
        case AGMapTypeSegmentedControlHybrid:
            
            self.mapView.mapType = MKMapTypeHybrid;
            break;
            
        default:
            break;
    }
    
}

-(void) actionDescription:(UIButton*) sender {
    
    //определяем владельца кнопки с помощью нашей функции
    MKAnnotationView *annotationView = [sender superAnnotationView]; //Так как это UIButton наследник UIView,то этот метод у него появился
    
    if (!annotationView) { //проверим,если он не nil. Эта запись равна annotation == nil
        return;
    }
    //Теперь мы уверены,что нашли эту АnnotationView.Берем координаты, которые у нас есть на нашей аннотации и с помощью берем адрес, чтобы показать в AlertView
    
    
    CLLocationCoordinate2D coordinate = annotationView.annotation.coordinate; //координаты Pin на чью кнопку "disclosere" нажали
    
    CLLocation *location = [[CLLocation alloc] initWithLatitude:coordinate.latitude
                                                      longitude:coordinate.longitude]; //инициализируем широту и долготу
    
    if ([self.geoCoder isGeocoding]) { // если чтото делает,то
        
        [self.geoCoder cancelGeocode]; //отменяем ,если нужно
    }
    
    [self.geoCoder reverseGeocodeLocation:location
                        completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) { //Делаем запрос к геокодеру по нашим координатам
                            
                            NSString *message = nil;
                            
                            if (error) {
                                
                                message = [error localizedDescription]; //если ошибка
                                
                            }else  {
                                
                                if ([placemarks count] > 0) {//если массив с адресом не пустой, выводим в сообщение
                                    
                                    CLPlacemark* placeMark = [placemarks firstObject]; //берем первый обьект
                                    message = [placeMark.addressDictionary description]; // У placeMark берем Dictionary и выводим на экран.description - описаник обьекта
                                    
                                }else {
                                    
                                    message = @"No placemarks found";
                                }
                                
                            }
                            
                            [self showAlertWithTitle:@"Location" andMessage:message];
                        }];
    
}

-(void) actionDirection:(UIButton*) sender {
    
    MKAnnotationView *annotationView = [sender superAnnotationView];
    
    if (!annotationView) {
        
        return;
    }
    if ([self.directions isCalculating]) { //если считает,то
        
        [self.directions cancel]; //отменяем
    }
    
    
    CLLocationCoordinate2D coordinate = annotationView.annotation.coordinate; //координаты Pin на чью кнопку "disclosere" нажали
    
    
    //для того,чтобы взять этот "road" (построить дорогу)
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init]; //это класс, наследник NSObject.У него есть "source" (начало) и "destination" (пункт назначения)Оба MKMapItem
    
    request.source = [MKMapItem mapItemForCurrentLocation]; //едем из текущей локации
    MKPlacemark *placeMark = [[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil]; //создаем placeMark (Dictionary нет,можно не добавлять)
    
    //destination будем делать из нашей пимпочки
    
    MKMapItem *destination = [[MKMapItem alloc]initWithPlacemark:placeMark]; //соз Item
    
    request.destination = destination; //едем в конечную точку
    
    request.transportType = MKDirectionsTransportTypeAutomobile; //выбор транспорта
    
    request.requestsAlternateRoutes = YES; //альтернативне пути (на каре рисует несколько маршрутов)
    
    self.directions = [[MKDirections alloc] initWithRequest:request]; // инициализируем нашим requestoм (соз проперти,чтобы сохранять) MKDirections -предоставляет маршрут на основе данных
    
    [self.directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) { //Калькулируем,Этот метод инициализирует запрос для направлений и вызывает блок обработчика завершения с результатами.Будет что-то считать
        if (error) {
            
            [self showAlertWithTitle:@"Error" andMessage:[error localizedDescription]]; //соз алерт с написанием ошибки
            
        }else if ([response.routes count] == 0 ) { //если данные о маршруте отсутствуют
            
            
            [self showAlertWithTitle:@"Error" andMessage:@"No routes found"]; //возможно этой ситуации не будет,но мы не доверяем
            
        }else { //здесь мы уверены,что в массиве больше чем "0"
            
            
            //у MKMapView на ряду с Annotation (теми точками которыми мы организуем) есть OVERLAYS,Оverlays - рисует поверх карты.
            [self.mapView removeOverlays:[self.mapView overlays]];//когда мы получили OVERLAYS,первым делом удаляем все текущие OVERLAYS.(удаляем все нарисованые маршруты)
            
            
            NSMutableArray *array = [NSMutableArray array]; // соз массив route
            
            for (MKRoute* route in response.routes) { //для каждой route в response
                
                [array addObject:route.polyline]; //добавляем обьект polyline (для каждого пути рисуем)
            }
            
            //НУЖЕН обязательный метод для раскрашивания Polyline методом -mapView:rendererForOverlay: !!!!!!
            
            [self.mapView addOverlays:array level:MKOverlayLevelAboveRoads]; //добавляем Оverlays (все наши Polyline которые собрали) (уровень :по верх дорог)
        }
        
    }];
}

- (void) showAlertWithTitle:(NSString*) title andMessage:(NSString*) message {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Okаy" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {}];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
    
    
}
#pragma mark- MKMapViewDelegate

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation NS_AVAILABLE(10_9, 4_0) { //метод показывает при загрузке карты местонаходение юзера (синий круг)
    
    
    //[self.mapView setRegion:MKCoordinateRegionMake(userLocation.coordinate, MKCoordinateSpanMake(0.1f, 0.1f))]; //масштаб
    
}

//чтобы была анимация для "Булавки (pin)"
- (nullable MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation { //в этот метод приходит анотация,что представляет собой модель обьекта ,его координату title и subtitle.Сюда можно добавлять свой view по этой координате,но мы будем использовать "default"
    
    
    if ([annotation isKindOfClass:[MKUserLocation class]]) {//когда приходит annotation,лучше проверить.Если пришла annotation от юзера,то mapView сам заботится,чтобы показать на карте локацию юзера (местонахождение)
        
        return nil;
    }
    
    static NSString *identifierPin = @"Annotation";
    
    MKPinAnnotationView *pin = (MKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:identifierPin];
    
    if (!pin) {
        
        pin = [[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:identifierPin];
        pin.pinTintColor = [UIColor redColor];
        pin.animatesDrop = YES;
        pin.canShowCallout = YES; //чтобы появлялся callout -это напись над pin
        pin.draggable = YES;
        
        //На pin когда нажимаем вылазит callout с пимпочкой, когда нажимаем выводиться детали локации (например адрес)
        UIButton *descriptionButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [descriptionButton addTarget:self action:@selector(actionDescription:) forControlEvents:UIControlEventTouchUpInside]; //Target - это тот обьект,которому будет посылаться метод (будет посылаться обьекту нашего класса AGViewController он у нас один)
        pin.rightCalloutAccessoryView = descriptionButton; //ставим справа
        
        //добавляем кнопку,которая создает маршрут
        UIButton *directionButton = [UIButton buttonWithType:UIButtonTypeContactAdd];
        [directionButton addTarget:self action:@selector(actionDirection:) forControlEvents:UIControlEventTouchUpInside];
        pin.leftCalloutAccessoryView = directionButton;
        
    }else {
        
        pin.annotation = annotation; //если существует,то меняем анотацию
    }
    return pin;
}

//Даем то,чем Xcode будет рисовать.Обязательный метод,чтобы нарисовать маршрут
//могут быть разные  render для разных overlays

-(MKOverlayRenderer*)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay {
    
    if ([overlay isKindOfClass:[MKPolyline class]]) { //если нам как overlays приходит polyline, то будем его рисовать
        
        MKPolylineRenderer *renderer =[[MKPolylineRenderer alloc]initWithOverlay:overlay]; //создаем (если бы приходили circle, то создавали MKCircleRenderer)
        renderer.lineWidth = 3.f; //ширина линий
        renderer.strokeColor = [UIColor colorWithRed:0.2f green:0.5f blue:0.7f alpha:0.9f];
        
        return renderer;
    }
    
    
    return nil;
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view didChangeDragState:(MKAnnotationViewDragState)newState
   fromOldState:(MKAnnotationViewDragState)oldState NS_AVAILABLE(10_9, 4_0) __TVOS_PROHIBITED { //можно отслеживать как наш State меняеться. Говорит,что наш annotationView изменил свое состояние, Pin имеет состояние (и координаты новые в annotation будут записаны )
    
    
    if (newState == MKAnnotationViewDragStateEnding) { //если закончили перетягивать "Pin"
        CLLocationCoordinate2D location = view.annotation.coordinate;
        
        MKMapPoint point = MKMapPointForCoordinate(location); //переводим в 2-х мерные координаты.Создаем точку
        
        NSLog(@"\n location = {%f, %f} \n point= %@",location.latitude , location.longitude , MKStringFromMapPoint(point));
        
    }
}

#pragma mark- UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {//когда начинаем вводить текст выезжает кнопка "Cancel"
    
    [searchBar becomeFirstResponder];
    [searchBar setShowsCancelButton:YES animated:NO];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar { //когда нажали "Cancel"
    
    [searchBar resignFirstResponder]; //прячем клаву
    [searchBar setShowsCancelButton:NO animated:YES];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {//метод вызывается,когда текст в searchBar изменился
    
    NSLog(@"textDidChange :%@",searchText);
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)theSearchBar
{
    [theSearchBar resignFirstResponder];
    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressString:theSearchBar.text completionHandler:^(NSArray *placemarks, NSError *error) {
        //Error checking
        
        CLPlacemark *placemark = [placemarks objectAtIndex:0];
        MKCoordinateRegion region;
        region.center = [(CLCircularRegion *)placemark.region center];
        
        MKCoordinateSpan span;
        
        double radius = placemark.region.radius /1000;
        
        NSLog(@"[searchBarSearchButtonClicked] Radius is %f", radius);
        
        span.latitudeDelta = radius / 112.0;
        
        region.span = span;
        
        [self.mapView setRegion:region animated:YES];
    }];
}
/*
 - (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated { //изменяем регио карты (region -это то что мы видим,наш view)
 
 NSLog(@"regionWillChangeAnimated");
 }
 - (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
 
 NSLog(@"regionDidChangeAnimated");
 }
 
 - (void)mapViewWillStartLoadingMap:(MKMapView *)mapView { //загружаем карту
 
 NSLog(@"mapViewWillStartLoadingMap");
 }
 - (void)mapViewDidFinishLoadingMap:(MKMapView *)mapView { //закончили загружать
 
 NSLog(@"mapViewDidFinishLoadingMap");
 }
 - (void)mapViewDidFailLoadingMap:(MKMapView *)mapView withError:(NSError *)error { //ошибка загрузки
 
 NSLog(@"mapViewDidFailLoadingMap with this error : %@",error);
 }
 
 - (void)mapViewWillStartRenderingMap:(MKMapView *)mapView NS_AVAILABLE(10_9, 7_0) { //передача карты
 
 NSLog(@"mapViewWillStartRenderingMap");
 
 }
 - (void)mapViewDidFinishRenderingMap:(MKMapView *)mapView fullyRendered:(BOOL)fullyRendered NS_AVAILABLE(10_9, 7_0) { //закончили передачу карт
 
 NSLog(@"mapViewDidFinishRenderingMap fullREndered =%d",fullyRendered); //полностью рендарится
 
 }
 */



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) dealloc { //пишем в dealloc,мы не знаем сделает ли он cancel.Мы не знаем как поведет себя geoCoder,не доверяем
    
    if ([self.geoCoder isGeocoding]) { //если делает
        
        [self.geoCoder cancelGeocode];
    }
    
    if ([self.directions isCalculating]) { //если считает
        
        [self.directions cancel]; // отменяем
    }
    
}

@end
