//
//  AGMapAnnotation.m
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGMapAnnotation.h"

@implementation AGMapAnnotation

@end
