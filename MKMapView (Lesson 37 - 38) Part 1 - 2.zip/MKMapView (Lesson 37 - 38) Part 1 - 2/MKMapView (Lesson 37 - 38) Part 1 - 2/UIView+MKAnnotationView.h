//
//  UIView+MKAnnotationView.h
//  MKMapView (Lesson 37 - 38) Part 1 - 2
//
//  Created by Anton Gorlov on 08.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MKAnnotationView; //обавляем класс (чтобы импорт не вставлять, в h. не надо вставлять h.),чтобы Xcode понял о чем речь в этой строчке -(MKAnnotationView*) superAnnotationView;

@interface UIView (MKAnnotationView)

//Чтобы узнать на какую кнопочку в pin нажали,сделаем категорию (раcширение)

-(MKAnnotationView*) superAnnotationView; //есть метод superView, который возвращает нашу родительскую View на кот. мы лежим.А у нас будет superAnnotationView, кот будет возвращать Annotation

@end
